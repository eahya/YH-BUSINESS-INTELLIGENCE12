"""YH Business Intelligence API."""
